﻿# Brief GPT — Génération de documentation

## Équipe
META

## Agent
META-Redaction

## But
Remplir/compléter les fichiers de documentation dans ce dossier SANS changer leurs noms.

## Livrables à produire
0) 07-InstructionsInt-META-Redaction.md : Instructions Internes pour GPT Custom.
1) 01-Profil.md : rôle, périmètre, exclusions, escalade.
2) 02-Prompt-interne.md : prompt stable.
3) 03-Variantes-prompt.md : variantes par cas d'usage.
4) 04-Amorces.md : 10 amorces de conversation.
5) 05-Exemples-usage.md : 5 scénarios (entrée→sortie).
6) 06-Changelog.md : entrée initiale + conventions versioning.

## Style
- concret, opérationnel, sections courtes
- pas d'URL inventée, pas de données fictives non marquées
- si hypothèse: écrire "Hypothèse à valider: …"

## Instructions Internes (fichier 07)
Ce fichier contient les instructions système pour le GPT Custom, incluant :
- Nom unique et description (≤ 300 caractères)
- Instructions système complètes
- Modes opératoires (si applicable)
- Format de réponse obligatoire
- Critères de qualité (DoD)
- 5 amorces de conversation
- Knowledge recommandé à uploader
