﻿# Exemples de Reference - IT-NetworkMaster

## Description

Ce dossier contient des **exemples concrets** illustrant les inputs acceptes et les outputs produits par IT-NetworkMaster.

## Nomenclature des fichiers

`
EX-[NNN]_[type]_[description-courte].md
Exemple : EX-001_nominal_rapport-patching-mensuel.md
`

---

*Exemples - IT-NetworkMaster v1.0*
