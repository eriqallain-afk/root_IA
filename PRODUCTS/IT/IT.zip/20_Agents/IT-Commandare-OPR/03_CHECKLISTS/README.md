﻿# Checklists de Validation - IT-Commandare-OPR

## Description

Ce dossier regroupe les **checklists de controle qualite** utilisees par IT-Commandare-OPR avant, pendant et apres la production de livrables.

## Types de checklists

- **Pre-execution** : Verification des conditions avant de demarrer
- **En-cours** : Points de controle pendant le traitement
- **Post-livraison** : Validation de la qualite du livrable final
- **Conformite** : Respect des standards et procedures MSP

## Format standard

Chaque item de checklist doit inclure :
- [ ] Case a cocher
- Description claire de l'element a verifier
- Critere de succes mesurable

---

*Checklists - IT-Commandare-OPR v1.0*
