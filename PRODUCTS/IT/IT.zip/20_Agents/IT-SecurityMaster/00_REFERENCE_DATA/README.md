﻿# Donnees de Reference - IT-SecurityMaster

## Description

Ce dossier centralise toutes les **donnees de reference statiques** utilisees par IT-SecurityMaster pour prendre des decisions et produire ses livrables.

## Contenu type

- Grilles tarifaires et baremes
- Standards et normes sectorielles (MSP, ITIL, etc.)
- Glossaires et definitions officielles
- Matrices de roles et responsabilites (RACI)
- Parametres de configuration de reference
- Seuils, limites et valeurs par defaut

## Utilisation

Ces donnees sont **consultees en lecture seule** par l'agent.  
Toute mise a jour doit etre validee avant remplacement.

---

*Reference Data - IT-SecurityMaster v1.0*
