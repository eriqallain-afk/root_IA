                                                                                                                                                                                                                                                                                                                                                                        # TEMPLATE — TEAMS NOTICE (COPIABLE)

## ⚠️ Début
(Caractère 12) [Client] — Début maintenance/intervention (#Ticket [#])
(Caractère 10) Fenêtre: [HH:MM–HH:MM]
(Caractère 10) Scope: [Serveurs/Services]

@NOC
## ✅ Fin
(Caractère 12) [Client] — Fin maintenance/intervention (#Ticket [#])
(Caractère 10) Résultat: [OK / Dégradé / Incident]
(Caractère 10) Suivi: [Aucun / Détails]

