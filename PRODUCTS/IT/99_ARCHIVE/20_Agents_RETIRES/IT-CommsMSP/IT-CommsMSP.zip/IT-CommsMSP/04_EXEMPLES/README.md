﻿# Exemples de Reference - IT-CommsMSP

## Description

Ce dossier contient des **exemples concrets** illustrant les inputs acceptes et les outputs produits par IT-CommsMSP.

## Nomenclature des fichiers

`
EX-[NNN]_[type]_[description-courte].md
Exemple : EX-001_nominal_rapport-patching-mensuel.md
`

---

*Exemples - IT-CommsMSP v1.0*
