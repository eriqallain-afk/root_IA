MSP Assistant – Démo interne
============================

Ce projet contient :

- Une base SQLite contenant les interventions MSP
- Des scripts Python pour créer la base, enregistrer les interventions et exporter les rapports
- Destiné à être utilisé avec le GPT personnalisé "MSP Assistant" qui génère :
    1. Discussion ConnectWise
    2. Note Interne ConnectWise
    3. Courriel Client
    4. Message Teams interne

Fichiers :
- DB\create_schema.sql : schéma de base
- DB\msp_assistant.db : base SQLite générée
- Scripts\create_db.py : création de la base
- Scripts\insert_entry.py : insertion d'une intervention
- Scripts\export_reports.py : export textes

Étapes :
1. Exécute create_db.py
2. Utilise ton GPT pour générer les 4 sections
3. Copie les sections dans insert_entry.py ou adapte l'appel
4. Exécute export_reports.py pour générer un fichier rapport
