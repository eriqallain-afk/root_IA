import sqlite3
import tkinter as tk
from tkinter import ttk, messagebox

DB = "C:\\MSP-Assistant\\DB\\msp_assistant.db"

def load_data():
    conn = sqlite3.connect(DB)
    cursor = conn.cursor()
    cursor.execute("SELECT id, client, ticket, technicien, debut, fin FROM interventions")
    rows = cursor.fetchall()
    conn.close()
    return rows

def open_row(event):
    item = tree.focus()
    id = tree.item(item)["values"][0]

    conn = sqlite3.connect(DB)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM interventions WHERE id=?", (id,))
    row = cursor.fetchone()
    conn.close()

    text.delete("1.0", tk.END)
    labels = ["ID", "Client", "Ticket", "Technicien", "Début", "Fin",
              "Résumé", "Note Interne", "Discussion", "Courriel Client",
              "Teams", "Scripts", "Diagnostic", "Chronologie", "Date"]
    for lbl, val in zip(labels, row):
        text.insert(tk.END, f"{lbl}:\n{val}\n\n")

root = tk.Tk()
root.title("MSP Assistant - Dashboard")

tree = ttk.Treeview(root, columns=("id","c","t","tech","d","f"), show="headings")
for col, name in zip(
    ("id","c","t","tech","d","f"),
    ("ID","Client","Ticket","Tech","Début","Fin")
):
    tree.heading(col, text=name)

for row in load_data():
    tree.insert("", tk.END, values=row)

tree.pack(fill="both", expand=True)
tree.bind("<Double-1>", open_row)

text = tk.Text(root, wrap="word")
text.pack(fill="both", expand=True)

root.mainloop()
