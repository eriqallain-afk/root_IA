import sqlite3
from datetime import datetime

db_path = "C:\\MSP-Assistant\\DB\\msp_assistant.db"

def save_intervention(
    client,
    ticket,
    technicien,
    debut,
    fin,
    resume,
    note_interne,
    discussion,
    courriel_client,
    teams,
    scripts_suggeres,
    diagnostic,
    chronologie
):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    cursor.execute("""
    INSERT INTO interventions (
        client, ticket, technicien, debut, fin, resume, note_interne,
        discussion, courriel_client, teams, scripts_suggeres, diagnostic,
        chronologie, date_enregistrement
    )
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        client,
        ticket,
        technicien,
        debut,
        fin,
        resume,
        note_interne,
        discussion,
        courriel_client,
        teams,
        scripts_suggeres,
        diagnostic,
        chronologie,
        datetime.now().strftime("%Y-%m-%d %H:%M")
    ))

    conn.commit()
    conn.close()
    print("✔ Intervention sauvegardée avec succès.")

# Example usage
if __name__ == "__main__":
    save_intervention(
        "Client Demo",
        "CW-1001",
        "Jean L.",
        "2025-02-06 13:00",
        "2025-02-06 13:42",
        "Résumé",
        "Note interne",
        "Discussion CW",
        "Courriel client",
        "Teams message",
        "Scripts PS",
        "Diagnostic",
        "Chronologie complète"
    )
