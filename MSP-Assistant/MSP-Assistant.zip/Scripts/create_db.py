import sqlite3
import os

path = "C:\\MSP-Assistant\\DB"
os.makedirs(path, exist_ok=True)

db = path + "\\msp_assistant.db"
schema = path + "\\create_schema.sql"

conn = sqlite3.connect(db)
cursor = conn.cursor()

with open(schema, "r", encoding="utf-8") as f:
    cursor.executescript(f.read())

conn.commit()
conn.close()
print("✔ Base de données créée :", db)
