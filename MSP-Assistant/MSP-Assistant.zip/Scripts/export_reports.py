import sqlite3
import os
from datetime import datetime

db_path = "C:\\MSP-Assistant\\DB\\msp_assistant.db"
output_folder = "C:\\MSP-Assistant\\Reports"

os.makedirs(output_folder, exist_ok=True)

conn = sqlite3.connect(db_path)
cursor = conn.cursor()

cursor.execute("SELECT * FROM interventions")
rows = cursor.fetchall()

for row in rows:
    id, client, ticket, technicien, debut, fin, resume, note_interne, discussion, courriel_client, teams, scripts, diagnostic, chronologie, date_enregistrement = row

    filename = f"{output_folder}\\Intervention_{id}_{ticket}.txt"

    with open(filename, "w", encoding="utf-8") as f:
        f.write(f"INTERVENTION #{id}\n")
        f.write(f"Client: {client}\n")
        f.write(f"Ticket: {ticket}\n")
        f.write(f"Technicien: {technicien}\n")
        f.write(f"Début: {debut}\n")
        f.write(f"Fin: {fin}\n")
        f.write(f"Date enregistrement: {date_enregistrement}\n\n")

        f.write("=== Discussion ConnectWise ===\n")
        f.write(discussion + "\n\n")

        f.write("=== Note Interne ConnectWise ===\n")
        f.write(note_interne + "\n\n")

        f.write("=== Courriel Client ===\n")
        f.write(courriel_client + "\n\n")

        f.write("=== Message Teams ===\n")
        f.write(teams + "\n\n")

        f.write("=== Scripts Suggérés ===\n")
        f.write(scripts + "\n\n")

        f.write("=== Diagnostic ===\n")
        f.write(diagnostic + "\n\n")

        f.write("=== Chronologie ===\n")
        f.write(chronologie + "\n\n")

    print(f"✔ Exporté : {filename}")

conn.close()
