﻿param(
    [string]$Client,
    [string]$Ticket,
    [string]$Tech,
    [string]$Resume,
    [string]$Note,
    [string]$Discussion,
    [string]$Mail,
    [string]$Teams,
    [string]$Scripts,
    [string]$Diag,
    [string]$Chrono
)

$debut = Get-Date -Format "yyyy-MM-dd HH:mm"
$fin = Get-Date -Format "yyyy-MM-dd HH:mm"

python "C:\MSP-Assistant\Scripts\insert_entry.py" $Client $Ticket $Tech $Resume $Note $Discussion
