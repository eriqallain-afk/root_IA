Python 3.14.3 (tags/v3.14.3:323c59a, Feb  3 2026, 16:04:56) [MSC v.1944 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.
>>> CREATE TABLE IF NOT EXISTS interventions (
...     id INTEGER PRIMARY KEY AUTOINCREMENT,
...     client TEXT,
...     ticket TEXT,
...     technicien TEXT,
...     debut TEXT,
...     fin TEXT,
...     resume TEXT,
...     note_interne TEXT,
...     discussion TEXT,
...     courriel_client TEXT,
...     teams TEXT,
...     scripts_suggeres TEXT,
...     diagnostic TEXT,
...     chronologie TEXT,
...     date_enregistrement TEXT
... );
