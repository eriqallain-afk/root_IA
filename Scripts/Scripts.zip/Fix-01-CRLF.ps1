<#
.SYNOPSIS
    Fix-01-CRLF.ps1 — Convertit tous les fichiers YAML de CRLF (Windows) → LF (Unix)
    Corrige 42 fichiers identifiés dans 20_AGENTS/
.DESCRIPTION
    PROBLÈME: 42 fichiers YAML encodés CRLF causent des erreurs silencieuses
    sur Linux/Mac et des échecs CI/CD.
    SOLUTION: Conversion LF + ajout .gitattributes pour prévention future.
.PARAMETER RootPath
    Chemin racine de la FACTORY (défaut: C:\Intranet_EA\EA_IA\root_IA)
.EXAMPLE
    .\Fix-01-CRLF.ps1
    .\Fix-01-CRLF.ps1 -RootPath "D:\monProjet\root_IA"
#>
param(
    [string]$RootPath = "C:\Intranet_EA\EA_IA\root_IA"
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

Write-Host "=== Fix-01-CRLF.ps1 — Normalisation encodage YAML ===" -ForegroundColor Cyan
Write-Host "Racine : $RootPath"
Write-Host ""

$fixedCount = 0
$skippedCount = 0
$errorCount = 0

# Cibles: 20_AGENTS/ + 00_CONTROL/ (récursif, tous les .yaml)
$targetDirs = @(
    Join-Path $RootPath "20_AGENTS"
    Join-Path $RootPath "00_CONTROL"
    Join-Path $RootPath "10_TEAMS"
    Join-Path $RootPath "30_PLAYBOOKS"
    Join-Path $RootPath "40_ROUTING"
    Join-Path $RootPath "50_POLICIES"
)

foreach ($dir in $targetDirs) {
    if (-not (Test-Path $dir)) {
        Write-Host "  [SKIP] Dossier absent: $dir" -ForegroundColor Yellow
        continue
    }

    $files = Get-ChildItem -Path $dir -Recurse -Filter "*.yaml" -File

    foreach ($file in $files) {
        try {
            $content = [System.IO.File]::ReadAllBytes($file.FullName)
            $text = [System.Text.Encoding]::UTF8.GetString($content)

            if ($text.Contains("`r`n")) {
                # Convertir CRLF → LF
                $fixed = $text -replace "`r`n", "`n"
                $bytes = [System.Text.Encoding]::UTF8.GetBytes($fixed)
                [System.IO.File]::WriteAllBytes($file.FullName, $bytes)

                $rel = $file.FullName.Replace($RootPath + "\", "")
                Write-Host "  [FIX] $rel" -ForegroundColor Green
                $fixedCount++
            } else {
                $skippedCount++
            }
        } catch {
            Write-Host "  [ERR] $($file.Name) — $($_.Exception.Message)" -ForegroundColor Red
            $errorCount++
        }
    }
}

Write-Host ""
Write-Host "─── Résultat ──────────────────────────────" -ForegroundColor Cyan
Write-Host "  Corrigés  : $fixedCount fichiers" -ForegroundColor Green
Write-Host "  OK déjà   : $skippedCount fichiers"
Write-Host "  Erreurs   : $errorCount fichiers" -ForegroundColor $(if ($errorCount -gt 0) { "Red" } else { "Green" })

# ─── PRÉVENTION FUTURE : .gitattributes ───────────────────────
$gitAttrPath = Join-Path $RootPath ".gitattributes"
$gitAttrContent = @"
# root_IA — Normalisation encodage Git
# Force LF pour tous les fichiers texte (évite CRLF Windows)
* text=auto

# YAML — toujours LF
*.yaml text eol=lf
*.yml  text eol=lf

# Markdown
*.md   text eol=lf

# Scripts Python
*.py   text eol=lf

# PowerShell — garder CRLF sur Windows pour compatibilité
*.ps1  text eol=crlf

# Binaires — pas de conversion
*.png  binary
*.jpg  binary
*.zip  binary
"@

if (Test-Path $gitAttrPath) {
    Write-Host ""
    Write-Host "  [EXIST] .gitattributes déjà présent — non écrasé." -ForegroundColor Yellow
    Write-Host "          Vérifier manuellement qu'il contient: *.yaml text eol=lf"
} else {
    $gitAttrContent | Out-File -FilePath $gitAttrPath -Encoding utf8 -NoNewline
    Write-Host ""
    Write-Host "  [NEW] .gitattributes créé dans $RootPath" -ForegroundColor Green
}

Write-Host ""
if ($errorCount -eq 0) {
    Write-Host "[OK] Fix-01 terminé avec succès." -ForegroundColor Green
} else {
    Write-Host "[WARN] Fix-01 terminé avec $errorCount erreur(s). Vérifier les fichiers en rouge." -ForegroundColor Yellow
}
