<#
.SYNOPSIS
    Fix-05-HUBOrchestrator.ps1 — Résoudre l'ambiguïté HUB-Orchestrator vs HUB-AgentMO

.DESCRIPTION
    PROBLÈME:
    Deux orchestrateurs coexistent dans HUB avec des rôles qui se chevauchent :

    HUB-Orchestrator (LEGACY)
    ├── Déclaré dans : teams.yaml (liste officielle)
    ├── Rôle         : Exécuteur de playbooks multi-étapes
    ├── Statut       : Actif mais prompt plus simple
    └── Problème     : Prête à confusion, n'est pas le MO principal

    HUB-AgentMO-MasterOrchestrator (ACTUEL)
    ├── Déclaré dans : hub_routing.yaml seulement (PAS dans teams.yaml)
    ├── Rôle         : Intake → Mapping → Dispatch → Compilation (COMPLET)
    ├── Statut       : Actif, prompt le plus complet de HUB
    └── Problème     : Absent de teams.yaml → invisible aux scans CTL

    HUB-AgentMO2-DeputyOrchestrator (ADJOINT QA)
    ├── Déclaré dans : Aucune source de vérité
    ├── Rôle         : QA validation du plan de MO
    └── Problème     : Totalement orphelin

    DÉCISION ARCHITECTURALE (confirmer avec Eric):
    Option A — Migration propre (recommandé):
        • HUB-AgentMO = orchestrateur principal (primary)
        • HUB-Orchestrator = déprécié (legacy/fallback)
        • HUB-AgentMO2 = adjoint QA (documented)
        • teams.yaml mis à jour

    Option B — Conservation des deux (si HUB-Orchestrator a des usages distincts):
        • Différencier clairement les rôles dans les prompts
        • HUB-Orchestrator = exécution playbooks mécanique
        • HUB-AgentMO = orchestration stratégique complexe
        • Les deux déclarés dans teams.yaml avec rôle distinct

    CE SCRIPT IMPLÉMENTE L'OPTION A (migration propre).
    Modifier la variable $Option pour choisir B.

.PARAMETER RootPath
    Chemin racine de la FACTORY
.PARAMETER Option
    "A" (migration, défaut) ou "B" (conservation différenciée)
.PARAMETER DryRun
    Voir les actions sans les exécuter
#>
param(
    [string]$RootPath = "C:\Intranet_EA\EA_IA\root_IA",
    [string]$Option   = "A",
    [switch]$DryRun
)

Set-StrictMode -Version Latest
$mode = if ($DryRun) { "[DRY-RUN]" } else { "[EXEC]" }

Write-Host "=== Fix-05-HUBOrchestrator.ps1 ===" -ForegroundColor Cyan
Write-Host "Mode   : $mode"
Write-Host "Option : $Option"
Write-Host ""

$teamsYaml = Join-Path $RootPath "10_TEAMS\teams.yaml"
$legacyDir = Join-Path $RootPath "20_AGENTS\HUB\HUB-Orchestrator"
$agentYaml = Join-Path $legacyDir "agent.yaml"

if ($Option -eq "A") {
    Write-Host "── OPTION A : Migration propre ─────────────────────────────" -ForegroundColor Yellow
    Write-Host ""

    # ACTION 1: Mettre HUB-Orchestrator en deprecated dans son agent.yaml
    Write-Host "ACTION 1 — Marquer HUB-Orchestrator comme deprecated"
    if (Test-Path $agentYaml) {
        $content = Get-Content $agentYaml -Raw
        if ($content -match "status:\s*[`"']?active") {
            if (-not $DryRun) {
                $updated = $content -replace "status:\s*[`"']?active[`"']?", 'status: "deprecated"'
                # Ajouter note deprecation
                $updated = $updated -replace "(status: `"deprecated`")", '$1' + "`ndeprecation_note: `"Remplacé par HUB-AgentMO-MasterOrchestrator (v2). Conserver comme fallback jusqu'au 2026-06-01.`""
                $updated = $updated -replace "`r`n", "`n"
                [System.IO.File]::WriteAllBytes($agentYaml, [System.Text.Encoding]::UTF8.GetBytes($updated))
                Write-Host "  [OK] HUB-Orchestrator/agent.yaml → status: deprecated" -ForegroundColor Green
            } else {
                Write-Host "  [DRY] HUB-Orchestrator → status: deprecated" -ForegroundColor Yellow
            }
        } else {
            Write-Host "  [SKIP] Déjà non-actif" -ForegroundColor Gray
        }
    }

    # ACTION 2: Mettre à jour teams.yaml — remplacer HUB-Orchestrator par HUB-AgentMO + MO2
    Write-Host ""
    Write-Host "ACTION 2 — Mettre à jour teams.yaml (TEAM__HUB)"

    if (Test-Path $teamsYaml) {
        $teams = Get-Content $teamsYaml -Raw

        # Remplacer la section agents de TEAM__HUB
        $oldAgents = @"
  agents:
    - HUB-Router
    - HUB-Concierge
    - HUB-Orchestrator
"@
        $newAgents = @"
  agents:
    - HUB-Router
    - HUB-Concierge
    - HUB-AgentMO-MasterOrchestrator
    - HUB-AgentMO2-DeputyOrchestrator
    - HUB-OproEngine
    - HUB-AvatarForge
    - HUB-CoachIA360-Strategie-GPTTeams
    - HUB-IA-ChatBotMaster
    - HUB-ITCoachIA360
    - HUB-Orchestrator  # DEPRECATED — conserver jusqu'au 2026-06-01
"@

        if ($teams -match [regex]::Escape("- HUB-Orchestrator")) {
            if (-not $DryRun) {
                $updated = $teams -replace [regex]::Escape($oldAgents), $newAgents
                if ($updated -eq $teams) {
                    # Fallback si le format exact ne correspond pas
                    Write-Host "  [WARN] Pattern exact non trouvé — mise à jour manuelle requise dans teams.yaml" -ForegroundColor Yellow
                    Write-Host "         Ajouter ces agents sous TEAM__HUB :"
                    Write-Host "           - HUB-AgentMO-MasterOrchestrator"
                    Write-Host "           - HUB-AgentMO2-DeputyOrchestrator"
                    Write-Host "           - HUB-OproEngine, HUB-AvatarForge, HUB-CoachIA360-Strategie-GPTTeams"
                    Write-Host "           - HUB-IA-ChatBotMaster, HUB-ITCoachIA360"
                    Write-Host "         Puis marquer: - HUB-Orchestrator  # DEPRECATED"
                } else {
                    $updated = $updated -replace "`r`n", "`n"
                    [System.IO.File]::WriteAllBytes($teamsYaml, [System.Text.Encoding]::UTF8.GetBytes($updated))
                    Write-Host "  [OK] teams.yaml mis à jour — 10 agents HUB déclarés" -ForegroundColor Green
                }
            } else {
                Write-Host "  [DRY] teams.yaml: HUB-Orchestrator → deprecated, MO + MO2 + autres ajoutés" -ForegroundColor Yellow
            }
        } else {
            Write-Host "  [INFO] Mettre à jour manuellement la section agents de TEAM__HUB dans teams.yaml" -ForegroundColor Cyan
        }
    }

    # ACTION 3: Ajouter HUB-AgentMO dans hub_routing.yaml si absent
    Write-Host ""
    Write-Host "ACTION 3 — Vérifier routing HUB-AgentMO dans hub_routing.yaml"
    $routingYaml = Join-Path $RootPath "40_ROUTING\hub_routing.yaml"
    if (Test-Path $routingYaml) {
        $routing = Get-Content $routingYaml -Raw
        if ($routing -match "HUB-AgentMO") {
            Write-Host "  [OK] HUB-AgentMO déjà dans hub_routing.yaml" -ForegroundColor Green
        } else {
            Write-Host "  [WARN] HUB-AgentMO absent du routing — ajouter manuellement:" -ForegroundColor Yellow
            Write-Host @"
  - intents: [orchestrate, intake, dispatch, master_orchestrate, complex_request]
    agent: HUB-AgentMO-MasterOrchestrator

  - intents: [qa_plan, validate_plan, deputy, review_mo]
    agent: HUB-AgentMO2-DeputyOrchestrator
"@
        }
    }

} elseif ($Option -eq "B") {
    Write-Host "── OPTION B : Conservation différenciée ─────────────────────" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Cette option conserve les deux orchestrateurs avec rôles distincts:"
    Write-Host ""
    Write-Host "  HUB-Orchestrator      = Exécution mécanique playbooks (step runner)"
    Write-Host "  HUB-AgentMO           = Orchestration stratégique (intake complexe)"
    Write-Host "  HUB-AgentMO2          = QA validation plans MO"
    Write-Host ""
    Write-Host "ACTIONS MANUELLES REQUISES pour l'Option B:"
    Write-Host "  1. Dans HUB-Orchestrator/prompt.md → Préciser: 'Je suis un EXÉCUTEUR de"
    Write-Host "     playbooks. Pour orchestration stratégique complexe → @HUB-AgentMO'"
    Write-Host "  2. Dans HUB-AgentMO/prompt.md → Préciser: 'Je suis l'ORCHESTRATEUR"
    Write-Host "     STRATÉGIQUE. Pour exécution mécanique de playbook → @HUB-Orchestrator'"
    Write-Host "  3. Ajouter dans teams.yaml: tous les agents HUB (voir Option A action 2)"
    Write-Host "  4. Ajouter dans hub_routing.yaml:"
    Write-Host "     - intents: [run_playbook, execute_playbook] → HUB-Orchestrator"
    Write-Host "     - intents: [orchestrate, dispatch, complex] → HUB-AgentMO"
    Write-Host ""
    Write-Host "  Ce script ne fait aucune modification pour l'Option B (manuel requis)." -ForegroundColor Yellow
} else {
    Write-Host "[ERREUR] Option invalide: $Option. Utiliser A ou B." -ForegroundColor Red
    exit 1
}

Write-Host ""
if ($DryRun) {
    Write-Host "[DRY-RUN] Aucune modification. Relancer sans -DryRun pour appliquer." -ForegroundColor Yellow
} else {
    Write-Host "[OK] Fix-05 terminé (Option $Option)." -ForegroundColor Green
}
