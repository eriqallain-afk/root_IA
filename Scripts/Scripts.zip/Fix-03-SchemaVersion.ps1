<#
.SYNOPSIS
    Fix-03-SchemaVersion.ps1 — Ajoute schema_version manquant sur 3 agents META

.DESCRIPTION
    PROBLÈME: META-PromptMaster, META-PlaybookBuilder, META-ArchitecteChoix
    n'ont pas de champ schema_version dans leur agent.yaml.
    CTL-WatchdogIA CHECK 1 les marque NON CONFORMES à chaque scan.

    CORRECTION: Injecter schema_version: "1.0" en première ligne de chaque
    agent.yaml concerné (après validation qu'il est absent).
#>
param(
    [string]$RootPath = "C:\Intranet_EA\EA_IA\root_IA"
)

Write-Host "=== Fix-03-SchemaVersion.ps1 ===" -ForegroundColor Cyan

$targets = @(
    "META-PromptMaster",
    "META-PlaybookBuilder",
    "META-ArchitecteChoix"
)

foreach ($agent in $targets) {
    $path = Join-Path $RootPath "20_AGENTS\META\$agent\agent.yaml"

    if (-not (Test-Path $path)) {
        Write-Host "  [SKIP] $agent — agent.yaml introuvable: $path" -ForegroundColor Yellow
        continue
    }

    $content = Get-Content $path -Raw

    if ($content -match "schema_version") {
        Write-Host "  [SKIP] $agent — schema_version déjà présent" -ForegroundColor Gray
        continue
    }

    # Injecter schema_version en tête du fichier (avant le premier champ)
    $injection = "schema_version: `"1.0`"`n"
    $newContent = $injection + $content

    # Convertir CRLF → LF en passant
    $newContent = $newContent -replace "`r`n", "`n"

    $bytes = [System.Text.Encoding]::UTF8.GetBytes($newContent)
    [System.IO.File]::WriteAllBytes($path, $bytes)

    Write-Host "  [OK] $agent — schema_version: `"1.0`" ajouté" -ForegroundColor Green
}

Write-Host ""
Write-Host "[OK] Fix-03 terminé." -ForegroundColor Green
