<#
.SYNOPSIS
    Fix-04-SyncOPS.ps1 — Synchronise les 3 agents OPS core vers tous les produits

.DESCRIPTION
    PROBLÈME: OPS-RouterIA, OPS-PlaybookRunner, OPS-DossierIA sont copiés manuellement
    dans 10 produits. Toute mise à jour OPS doit être propagée à la main → désync.

    SOLUTION: Ce script copie les agents OPS canoniques (FACTORY/20_AGENTS/OPS/)
    vers chaque produit qui les contient, en écrasant les copies existantes.
    Exécuter après toute modification d'un agent OPS.

    ARCHITECTURE INTENTIONNELLE:
    Les copies OPS dans les produits sont des snapshots locaux intentionnels —
    ils garantissent l'autonomie de chaque produit sans dépendance réseau.
    Ce script est le mécanisme de synchronisation de ces snapshots.

.PARAMETER RootPath
    Chemin racine de la FACTORY
.PARAMETER ProductsPath
    Chemin racine des PRODUCTS (défaut: <RootPath>\..\PRODUCTS)
.PARAMETER DryRun
    Afficher les actions sans les exécuter
.EXAMPLE
    .\Fix-04-SyncOPS.ps1 -DryRun
    .\Fix-04-SyncOPS.ps1
#>
param(
    [string]$RootPath    = "C:\Intranet_EA\EA_IA\root_IA",
    [string]$ProductsPath = "",
    [switch]$DryRun
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# Résoudre ProductsPath
if (-not $ProductsPath) {
    $ProductsPath = Join-Path (Split-Path $RootPath -Parent) "PRODUCTS"
}

$mode = if ($DryRun) { "[DRY-RUN]" } else { "[EXEC]" }
Write-Host "=== Fix-04-SyncOPS.ps1 — Synchronisation agents OPS ==="  -ForegroundColor Cyan
Write-Host "Mode     : $mode"
Write-Host "FACTORY  : $RootPath"
Write-Host "PRODUCTS : $ProductsPath"
Write-Host ""

# ─── Sources canoniques ─────────────────────────────────────────
$opsAgents = @("OPS-RouterIA", "OPS-PlaybookRunner", "OPS-DossierIA")
$sourceBase = Join-Path $RootPath "20_AGENTS\OPS"

# Vérifier sources
foreach ($agent in $opsAgents) {
    $src = Join-Path $sourceBase $agent
    if (-not (Test-Path $src)) {
        Write-Host "[ERREUR] Source OPS introuvable: $src" -ForegroundColor Red
        Write-Host "         Vérifier que FACTORY\20_AGENTS\OPS\ contient les 3 agents."
        exit 1
    }
}
Write-Host "Sources OPS (canoniques):" -ForegroundColor DarkCyan
foreach ($a in $opsAgents) { Write-Host "  ✓ $a" }
Write-Host ""

# ─── Produits cibles ────────────────────────────────────────────
# Identifier produits qui contiennent déjà au moins 1 agent OPS
if (-not (Test-Path $ProductsPath)) {
    Write-Host "[ERREUR] Dossier PRODUCTS introuvable: $ProductsPath" -ForegroundColor Red
    exit 1
}

$products = Get-ChildItem -Path $ProductsPath -Directory

$syncCount    = 0
$skippedCount = 0
$totalFiles   = 0

foreach ($product in $products) {
    # Vérifier si ce produit a des agents OPS à synchroniser
    $hasOPS = $false
    foreach ($agent in $opsAgents) {
        if (Test-Path (Join-Path $product.FullName $agent)) {
            $hasOPS = $true
            break
        }
    }

    if (-not $hasOPS) {
        Write-Host "  [SKIP] $($product.Name) — aucun agent OPS détecté" -ForegroundColor Gray
        $skippedCount++
        continue
    }

    Write-Host "  → $($product.Name)" -ForegroundColor White

    foreach ($agent in $opsAgents) {
        $srcDir  = Join-Path $sourceBase $agent
        $destDir = Join-Path $product.FullName $agent

        if (-not (Test-Path $destDir)) {
            Write-Host "    [SKIP] $agent absent dans ce produit (non créé)" -ForegroundColor Gray
            continue
        }

        # Copier récursivement
        $files = Get-ChildItem -Path $srcDir -Recurse -File
        foreach ($file in $files) {
            $relativePath = $file.FullName.Substring($srcDir.Length)
            $destFile = Join-Path $destDir $relativePath.TrimStart('\')
            $destFileDir = Split-Path $destFile -Parent

            if (-not $DryRun) {
                if (-not (Test-Path $destFileDir)) {
                    New-Item -ItemType Directory -Path $destFileDir -Force | Out-Null
                }
                Copy-Item $file.FullName $destFile -Force
            }
            $totalFiles++
        }

        $verb = if ($DryRun) { "Synchro" } else { "Synchronisé" }
        Write-Host "    [$verb] $agent ($($files.Count) fichiers)" -ForegroundColor Green
    }

    $syncCount++
}

Write-Host ""
Write-Host "─── Résultat ───────────────────────────────────────" -ForegroundColor Cyan
Write-Host "  Produits synchronisés : $syncCount"
Write-Host "  Produits ignorés      : $skippedCount"
Write-Host "  Fichiers traités      : $totalFiles"
Write-Host ""

# ─── Mise à jour version OPS dans chaque copie ──────────────────
# Lire version source depuis agent.yaml OPS-RouterIA
$sourceAgentYaml = Join-Path $sourceBase "OPS-RouterIA\agent.yaml"
if (Test-Path $sourceAgentYaml) {
    $version = (Get-Content $sourceAgentYaml | Select-String "^version:") -replace "version:\s*[`"']?", "" -replace "[`"']", ""
    Write-Host "  Version OPS synchronisée : $version"
}

Write-Host ""
if ($DryRun) {
    Write-Host "[DRY-RUN] Aucune modification. Relancer sans -DryRun pour appliquer." -ForegroundColor Yellow
} else {
    Write-Host "[OK] Fix-04 terminé. Agents OPS synchronisés dans $syncCount produits." -ForegroundColor Green
    Write-Host ""
    Write-Host "RAPPEL: Planifier ce script dans le pipeline CI/CD ou Task Scheduler"
    Write-Host "        après chaque modification dans 20_AGENTS\OPS\"
}
