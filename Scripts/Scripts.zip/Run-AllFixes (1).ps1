<#
.SYNOPSIS
    Run-AllFixes.ps1 — Lance tous les correctifs dans l'ordre optimal

.DESCRIPTION
    Ordre d'exécution:
    01  CRLF          → Pre-requis pour que tous les YAML soient lisibles
    02  Routing        → Consolider sources de vérité routing
    03  SchemaVersion  → 3 agents META non conformes
    04  SyncOPS        → Propager OPS vers les produits
    05  HUBOrchestrator→ Déprécier HUB-Orchestrator legacy

.PARAMETER RootPath
    Chemin racine FACTORY
.PARAMETER ProductsPath
    Chemin racine PRODUCTS
.PARAMETER DryRun
    Preview seulement — aucune modification
.PARAMETER StopOnError
    Arrêter à la première erreur
.EXAMPLE
    # Test complet sans modification
    .\Run-AllFixes.ps1 -DryRun

    # Correction complète
    .\Run-AllFixes.ps1

    # Correction partielle — CRLF + SchemaVersion seulement
    .\Fix-01-CRLF.ps1
    .\Fix-03-SchemaVersion.ps1
#>
param(
    [string]$RootPath     = "C:\Intranet_EA\EA_IA\root_IA",
    [string]$ProductsPath = "",
    [switch]$DryRun,
    [switch]$StopOnError
)

Set-StrictMode -Version Latest
$here = $PSScriptRoot

$mode = if ($DryRun) { "DRY-RUN" } else { "EXECUTION" }
Write-Host ""
Write-Host "╔══════════════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║           Run-AllFixes.ps1 — root_IA Corrections Majeures       ║" -ForegroundColor Cyan
Write-Host "╠══════════════════════════════════════════════════════════════════╣" -ForegroundColor Cyan
Write-Host "║  Mode     : $($mode.PadRight(53))║" -ForegroundColor Cyan
Write-Host "║  FACTORY  : $($RootPath.PadRight(53))║" -ForegroundColor Cyan
Write-Host "╚══════════════════════════════════════════════════════════════════╝" -ForegroundColor Cyan
Write-Host ""

$results = @()
$globalOK = $true

function Run-Fix {
    param([string]$Script, [string]$Description, [hashtable]$Params)

    Write-Host ""
    Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor DarkCyan
    Write-Host "  $Script — $Description" -ForegroundColor White
    Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor DarkCyan
    Write-Host ""

    $scriptPath = Join-Path $here $Script
    if (-not (Test-Path $scriptPath)) {
        Write-Host "  [ERREUR] Script introuvable: $scriptPath" -ForegroundColor Red
        return [PSCustomObject]@{ Script = $Script; Status = "MISSING"; OK = $false }
    }

    try {
        $sw = [System.Diagnostics.Stopwatch]::StartNew()
        & $scriptPath @Params
        $sw.Stop()
        $status = if ($LASTEXITCODE -eq 0 -or $null -eq $LASTEXITCODE) { "OK" } else { "WARN" }
        return [PSCustomObject]@{ Script = $Script; Status = $status; Duration = $sw.Elapsed.TotalSeconds; OK = $true }
    } catch {
        Write-Host "  [ERREUR] $($_.Exception.Message)" -ForegroundColor Red
        return [PSCustomObject]@{ Script = $Script; Status = "ERROR: $($_.Exception.Message)"; OK = $false }
    }
}

$baseParams = @{ RootPath = $RootPath }
if ($DryRun) { $baseParams.DryRun = $true }

$opsParams = $baseParams.Clone()
if ($ProductsPath) { $opsParams.ProductsPath = $ProductsPath }

# ─── Exécution dans l'ordre ──────────────────────────────────
$results += Run-Fix "Fix-01-CRLF.ps1"           "Normalisation encodage CRLF → LF (42 fichiers)"       $baseParams
if ($StopOnError -and -not $results[-1].OK) { goto end }

$results += Run-Fix "Fix-02-Routing.ps1"         "Consolidation hub_routing.yaml (4→2 sources)"         $baseParams
if ($StopOnError -and -not $results[-1].OK) { goto end }

$results += Run-Fix "Fix-03-SchemaVersion.ps1"   "Ajout schema_version (3 agents META)"                 $baseParams
if ($StopOnError -and -not $results[-1].OK) { goto end }

$results += Run-Fix "Fix-04-SyncOPS.ps1"         "Synchronisation agents OPS core vers 10 produits"     $opsParams
if ($StopOnError -and -not $results[-1].OK) { goto end }

$results += Run-Fix "Fix-05-HUBOrchestrator.ps1" "Dépreciation HUB-Orchestrator legacy (Option A)"      $baseParams

:end

# ─── Rapport final ────────────────────────────────────────────
Write-Host ""
Write-Host "╔══════════════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║                    RAPPORT FINAL                                  ║" -ForegroundColor Cyan
Write-Host "╠══════════════════════════════════════════════════════════════════╣" -ForegroundColor Cyan

foreach ($r in $results) {
    $color = if ($r.OK) { "Green" } else { "Red" }
    $icon  = if ($r.OK) { "✅" } else { "❌" }
    $dur   = if ($r.Duration) { " ($([math]::Round($r.Duration,1))s)" } else { "" }
    Write-Host "║  $icon  $($r.Script.PadRight(35)) $($r.Status.PadRight(18))$dur" -ForegroundColor $color
}

$allOK = ($results | Where-Object { -not $_.OK }).Count -eq 0
Write-Host "╠══════════════════════════════════════════════════════════════════╣" -ForegroundColor Cyan
if ($allOK) {
    Write-Host "║  RÉSULTAT : TOUS LES CORRECTIFS APPLIQUÉS AVEC SUCCÈS           ║" -ForegroundColor Green
} else {
    $errCount = ($results | Where-Object { -not $_.OK }).Count
    Write-Host "║  RÉSULTAT : $errCount correctif(s) en erreur — vérifier les logs  ║" -ForegroundColor Red
}
Write-Host "╚══════════════════════════════════════════════════════════════════╝" -ForegroundColor Cyan
Write-Host ""

if (-not $DryRun -and $allOK) {
    Write-Host "PROCHAINES ÉTAPES RECOMMANDÉES:" -ForegroundColor White
    Write-Host "  1. Lancer Run-Validation.ps1 pour confirmer conformité"
    Write-Host "  2. Lancer FACTORY_HEALTH_CHECK (playbook CTL) pour score post-fix"
    Write-Host "  3. Committer les changements dans Git"
    Write-Host "  4. Ajouter .gitattributes au commit (prévention CRLF futur)"
    Write-Host ""
    Write-Host "  Commande de validation:"
    Write-Host "  .\99_VALIDATION\Run-Validation.ps1 -RootPath `"$RootPath`"" -ForegroundColor Gray
}
