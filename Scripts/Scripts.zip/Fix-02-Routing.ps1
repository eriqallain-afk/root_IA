<#
.SYNOPSIS
    Fix-02-Routing.ps1 — Consolide les 4 copies de hub_routing.yaml

.DESCRIPTION
    DÉCOUVERTE IMPORTANTE (audit 2026-03-01) :
    Les 4 fichiers hub_routing.yaml NE SONT PAS de simples doublons.
    Ils servent deux routers différents avec deux formats différents :

    ┌─────────────────────────────────────────────────────────────────────┐
    │ 40_ROUTING/hub_routing.yaml    v2.0  113L  → router: HUB-Router    │
    │   • Format: intents[] + agent: + playbook:                          │
    │   • Couvre: CTL, HUB, META, IAHQ, OPS + agents spécialisés         │
    │   • SOURCE DE VÉRITÉ FACTORY                                        │
    ├─────────────────────────────────────────────────────────────────────┤
    │ 80_MACHINES/hub_routing.yaml   v1.0  305L  → router: OPS-RouterIA  │
    │   • Format: match_any_intents[] + default_actor_id: + playbook_id:  │
    │   • Couvre: orchestrateurs PRODUCTS (IT, DAM, EDU, IASM, TRAD...)  │
    │   • SOURCE DE VÉRITÉ PRODUCTS                                       │
    ├─────────────────────────────────────────────────────────────────────┤
    │ 40_RUNBOOKS/hub_routing.yaml   v2.0   87L  → ANCIENNE VERSION      │
    │   • Contenu partiel de 40_ROUTING/ (version antérieure incomplète)  │
    │   • ACTION: SUPPRIMER                                               │
    ├─────────────────────────────────────────────────────────────────────┤
    │ 90_KNOWLEDGE/LEGACY_MO-HUB/hub_routing.yaml  v1  78L → LEGACY v1  │
    │   • Première version du routing (projet IA-Multiverse)              │
    │   • ACTION: CONSERVER (archive historique, ne pas supprimer)        │
    └─────────────────────────────────────────────────────────────────────┘

    ACTIONS:
    1. Renommer 80_MACHINES/hub_routing.yaml → products_routing.yaml
       (pour clarifier que ce fichier gère les PRODUCTS, pas la FACTORY)
    2. Supprimer 40_RUNBOOKS/hub_routing.yaml (doublon partiel de 40_ROUTING)
    3. Mettre à jour les références dans META_ORCHESTRATOR_V2.yaml
    4. Ajouter header de documentation dans les deux sources de vérité

.PARAMETER RootPath
    Chemin racine de la FACTORY
.PARAMETER DryRun
    Afficher les actions sans les exécuter (test)
.EXAMPLE
    .\Fix-02-Routing.ps1 -DryRun            # Voir ce qui sera fait
    .\Fix-02-Routing.ps1                     # Exécuter les corrections
#>
param(
    [string]$RootPath = "C:\Intranet_EA\EA_IA\root_IA",
    [switch]$DryRun
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$mode = if ($DryRun) { "[DRY-RUN]" } else { "[EXEC]" }
Write-Host "=== Fix-02-Routing.ps1 — Consolidation hub_routing.yaml ===" -ForegroundColor Cyan
Write-Host "Mode     : $mode"
Write-Host "Racine   : $RootPath"
Write-Host ""

# ─── PATHS ────────────────────────────────────────────────────
$canonical   = Join-Path $RootPath "40_ROUTING\hub_routing.yaml"
$machines    = Join-Path $RootPath "80_MACHINES\hub_routing.yaml"
$runbooks    = Join-Path $RootPath "40_RUNBOOKS\hub_routing.yaml"
$legacy      = Join-Path $RootPath "90_KNOWLEDGE\LEGACY_MO-HUB\hub_routing.yaml"
$machinesNew = Join-Path $RootPath "80_MACHINES\products_routing.yaml"
$orchestrV2  = Join-Path $RootPath "80_MACHINES\META_ORCHESTRATOR_V2.yaml"
$backupDir   = Join-Path $RootPath "90_KNOWLEDGE\BACKUPS_ROUTING"

# ─── ACTION 0: Backup ─────────────────────────────────────────
Write-Host "ACTION 0 — Backup des fichiers avant modification"
if (-not $DryRun) {
    if (-not (Test-Path $backupDir)) { New-Item -ItemType Directory -Path $backupDir -Force | Out-Null }
    $ts = Get-Date -Format "yyyyMMdd_HHmmss"
    foreach ($f in @($canonical, $machines, $runbooks)) {
        if (Test-Path $f) {
            $dest = Join-Path $backupDir "$(Split-Path $f -Leaf)_backup_$ts"
            Copy-Item $f $dest
            Write-Host "  [BACKUP] $(Split-Path $f -Leaf) → BACKUPS_ROUTING\" -ForegroundColor Gray
        }
    }
} else {
    Write-Host "  [DRY] Backups seraient créés dans $backupDir"
}

Write-Host ""

# ─── ACTION 1: Renommer 80_MACHINES/hub_routing.yaml ──────────
Write-Host "ACTION 1 — Renommer 80_MACHINES/hub_routing.yaml → products_routing.yaml"
Write-Host "  Raison: Ce fichier utilise OPS-RouterIA (pas HUB-Router) et couvre"
Write-Host "          les orchestrateurs PRODUCTS. Son nom actuel est trompeur."

if (Test-Path $machines) {
    if (-not $DryRun) {
        # Ajouter header explicatif
        $content = Get-Content $machines -Raw
        $header = @"
# ═══════════════════════════════════════════════════════════════════════════════
# products_routing.yaml — Routing PRODUCTS root_IA
# ═══════════════════════════════════════════════════════════════════════════════
# Router       : OPS-RouterIA (dans chaque produit)
# Scope        : Orchestrateurs PRODUCTS (IT, DAM, EDU, IASM, TRAD, NEA, PLR)
# Format       : match_any_intents[] + default_actor_id + default_playbook_id
# Source vérité: OUI pour le routing PRODUCTS
# Canonical    : 80_MACHINES/products_routing.yaml
# Mise à jour  : Manuellement après ajout d'un nouveau produit
# ═══════════════════════════════════════════════════════════════════════════════
# DIFFÉRENCE avec 40_ROUTING/hub_routing.yaml:
#   • 40_ROUTING/ → HUB-Router → agents FACTORY (CTL, META, IAHQ...)
#   • 80_MACHINES/ → OPS-RouterIA → orchestrateurs PRODUCTS
# ═══════════════════════════════════════════════════════════════════════════════

"@
        # Remplacer commentaire en-tête existant
        $newContent = $header + ($content -replace "(?s)^#.*?(?=\n\s*schema_version)", "")
        $newContent | Out-File -FilePath $machinesNew -Encoding utf8 -NoNewline
        Remove-Item $machines
        Write-Host "  [OK] Renommé → 80_MACHINES\products_routing.yaml" -ForegroundColor Green
    } else {
        Write-Host "  [DRY] Renommerait hub_routing.yaml → products_routing.yaml" -ForegroundColor Yellow
    }
} else {
    Write-Host "  [SKIP] 80_MACHINES\hub_routing.yaml introuvable" -ForegroundColor Yellow
}

Write-Host ""

# ─── ACTION 2: Supprimer 40_RUNBOOKS/hub_routing.yaml ─────────
Write-Host "ACTION 2 — Supprimer 40_RUNBOOKS/hub_routing.yaml"
Write-Host "  Raison: Ancienne version partielle (87L vs 113L dans 40_ROUTING/)."
Write-Host "          Même schema_version v2.0 mais routes manquantes → risque de"
Write-Host "          confusion. Aucun agent ne doit référencer ce chemin."

if (Test-Path $runbooks) {
    if (-not $DryRun) {
        Remove-Item $runbooks
        Write-Host "  [OK] Supprimé: 40_RUNBOOKS\hub_routing.yaml" -ForegroundColor Green
    } else {
        Write-Host "  [DRY] Supprimerait 40_RUNBOOKS\hub_routing.yaml" -ForegroundColor Yellow
    }
} else {
    Write-Host "  [SKIP] Déjà absent" -ForegroundColor Gray
}

Write-Host ""

# ─── ACTION 3: Ajouter header dans 40_ROUTING/hub_routing.yaml ─
Write-Host "ACTION 3 — Documenter la source de vérité 40_ROUTING/hub_routing.yaml"

if (Test-Path $canonical) {
    $canonContent = Get-Content $canonical -Raw
    if (-not $canonContent.StartsWith("# ═══")) {
        $canonHeader = @"
# ═══════════════════════════════════════════════════════════════════════════════
# hub_routing.yaml — Routing FACTORY root_IA  [SOURCE DE VÉRITÉ]
# ═══════════════════════════════════════════════════════════════════════════════
# Router       : HUB-Router
# Scope        : Tous les agents FACTORY (CTL, HUB, META, OPS, IAHQ) +
#                agents spécialisés PRODUCTS (IT-ScriptMaster, DAM-Conformite...)
# Format       : intents[] + agent: + playbook: (optionnel)
# Source vérité: OUI — fichier canonique unique pour FACTORY
# Canonical    : 40_ROUTING/hub_routing.yaml
# Synchroniser : Copier vers 80_MACHINES/ si besoin (script: Sync-Routing.ps1)
# ═══════════════════════════════════════════════════════════════════════════════
# DIFFÉRENCE avec 80_MACHINES/products_routing.yaml:
#   • Ce fichier → HUB-Router → agents granulaires FACTORY
#   • 80_MACHINES/ → OPS-RouterIA → orchestrateurs haut niveau PRODUCTS
# ═══════════════════════════════════════════════════════════════════════════════

"@
        if (-not $DryRun) {
            $newCanon = $canonContent -replace "^# Hub Routing.*\n", ""
            ($canonHeader + $newCanon) | Out-File -FilePath $canonical -Encoding utf8 -NoNewline
            Write-Host "  [OK] Header documentaire ajouté dans 40_ROUTING\hub_routing.yaml" -ForegroundColor Green
        } else {
            Write-Host "  [DRY] Ajouterait header dans 40_ROUTING\hub_routing.yaml" -ForegroundColor Yellow
        }
    } else {
        Write-Host "  [SKIP] Header déjà présent" -ForegroundColor Gray
    }
}

Write-Host ""

# ─── ACTION 4: Mettre à jour META_ORCHESTRATOR_V2.yaml ─────────
Write-Host "ACTION 4 — Mettre à jour référence dans META_ORCHESTRATOR_V2.yaml"
Write-Host "  (hub_routing → products_routing pour la référence 80_MACHINES)"

if (Test-Path $orchestrV2) {
    $orchContent = Get-Content $orchestrV2 -Raw
    if ($orchContent -match "hub_routing\.yaml") {
        if (-not $DryRun) {
            # Remplacer référence 80_MACHINES/hub_routing par products_routing
            $orchFixed = $orchContent -replace "80_MACHINES/hub_routing\.yaml", "80_MACHINES/products_routing.yaml"
            $orchFixed = $orchFixed -replace "80_MACHINES\\hub_routing\.yaml", "80_MACHINES\products_routing.yaml"
            $orchFixed | Out-File -FilePath $orchestrV2 -Encoding utf8 -NoNewline
            Write-Host "  [OK] Référence mise à jour dans META_ORCHESTRATOR_V2.yaml" -ForegroundColor Green
        } else {
            Write-Host "  [DRY] Mettrait à jour hub_routing → products_routing dans META_ORCHESTRATOR_V2.yaml" -ForegroundColor Yellow
        }
    } else {
        Write-Host "  [SKIP] Aucune référence hub_routing trouvée dans META_ORCHESTRATOR_V2.yaml" -ForegroundColor Gray
    }
} else {
    Write-Host "  [SKIP] META_ORCHESTRATOR_V2.yaml introuvable" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "─── Résumé final ──────────────────────────────────────" -ForegroundColor Cyan
Write-Host "  Sources de vérité APRÈS fix:"
Write-Host "  • FACTORY   : 40_ROUTING\hub_routing.yaml       (HUB-Router)"
Write-Host "  • PRODUCTS  : 80_MACHINES\products_routing.yaml  (OPS-RouterIA)"
Write-Host "  • LEGACY    : 90_KNOWLEDGE\LEGACY_MO-HUB\ (archive — ne pas modifier)"
Write-Host ""
if ($DryRun) {
    Write-Host "[DRY-RUN] Aucune modification effectuée. Relancer sans -DryRun pour appliquer." -ForegroundColor Yellow
} else {
    Write-Host "[OK] Fix-02 terminé." -ForegroundColor Green
}
